console.log('hey from the content-script');
self.thisIsTheContentScript = true;

