const base = require('./base');

module.exports = {
  ...base,
  spec: 'utils/doclint/**/*.spec.js',
};
