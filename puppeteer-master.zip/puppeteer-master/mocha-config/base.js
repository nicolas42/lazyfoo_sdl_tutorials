module.exports = {
  reporter: 'dot',
};
