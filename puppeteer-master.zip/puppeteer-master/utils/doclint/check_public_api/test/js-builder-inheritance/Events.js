const Events = {
  B: {
    // Event with the same name as a super class method.
    foo: 'foo',
  },
};

module.exports = {Events};
