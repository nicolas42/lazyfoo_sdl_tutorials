### class: Foo

#### foo.$()

#### foo.money$$money()

#### foo.proceed()

#### foo.start()

