class Other {
}
