const Events = {
  Foo: {
    a: 'a',
    b: 'b',
    c: 'c',
  },
};
module.exports = {Events};
