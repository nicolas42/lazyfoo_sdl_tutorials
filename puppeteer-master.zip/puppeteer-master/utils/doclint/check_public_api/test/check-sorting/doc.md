### class: Foo

#### event: 'c'

#### event: 'a'

#### foo.aaa()

#### event: 'b'

#### foo.ddd

#### foo.ccc()

#### foo.bbb()
