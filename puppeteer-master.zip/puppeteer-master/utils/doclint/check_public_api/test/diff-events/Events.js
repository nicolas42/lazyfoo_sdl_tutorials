const Events = {
  Foo: {
    Start: 'start',
    Finish: 'finish',
  },
};

module.exports = {Events};
