class Foo {
  test() {
  }

  /**
   * @param {number} arg
   */
  title(arg) {
  }
}

class Bar {
}
