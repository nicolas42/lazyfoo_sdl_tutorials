/*\
title: a/b/c/d.js
type: application/javascript
module-type: library

Nested test

\*/

exports.foo = function () {
    return 1;
};


