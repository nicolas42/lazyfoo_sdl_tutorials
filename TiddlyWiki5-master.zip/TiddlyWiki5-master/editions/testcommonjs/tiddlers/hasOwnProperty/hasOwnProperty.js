/*\
title: hasOwnProperty.js
type: application/javascript
module-type: library

OwnProperty test A

\*/
